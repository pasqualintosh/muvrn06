export const ADD_TRACKING = "ADD_TRACKING";
export const RESET_TRACKING = "RESET_TRACKING";
export const SAVE_TRACKING_SUCCESS = "SAVE_TRACKING_SUCCESS";
export const SAVE_TRACKING_ERROR = "SAVE_TRACKING_ERROR";
export const ADD_ACTIVITY = "ADD_ACTIVITY";
export const CONTROL_ACTIVITY = "CONTROL_ACTIVITY";
export const UPDATE_LOCATION = "UPDATE_LOCATION";
export const START_LOCATION = "START_LOCATION";
export const STOP_LOCATION = "STOP_LOCATION";
export const UPDATE_STATUS = "UPDATE_STATUS";
export const COMPLETE_ROUTE = "COMPLETE_ROUTE";
export const CHANGE_ACTIVITY = "CHANGE_ACTIVITY";

export const ADD_DAILY_ROUTINE = "ADD_DAILY_ROUTINE";
export const DELETE_DAILY_ROUTINE = "ADD_DAILY_ROUTINE";
export const UPDATE_PREVIOUS_ROUTE = "UPDATE_PREVIOUS_ROUTE";
export const RESET_PREVIOUS_ROUTE = "RESET_PREVIOUS_ROUTE";

export const ADD_WEATHER = "ADD_WEATHER";

export const STILL_NOTIFICATION_LOG = "STILL_NOTIFICATION_LOG";
export const ADD_REFER_PUBLIC_ROUTE = "ADD_REFER_PUBLIC_ROUTE";


// per aggiungere una proprieta alla route prima di considerarla analizzata
// posso aggiungere se è stata cercata la stazioni o le linee, utile per sapere a che punto sono  
export const ADD_STATUS_ROUTE = "ADD_STATUS_ROUTE";
export const FIX_ROUTE_START = "FIX_ROUTE_START";


export const PLAY_FROM_NOTIFICATION = "PLAY_FROM_NOTIFICATION";

